package com.example.janhavi.model;

import java.time.LocalDate;
import java.util.Map;
import java.util.HashMap;
import jakarta.persistence.Column;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;


import jakarta.persistence.*;
@Entity
@Table(name="product")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String productName;

    @Column
    private String useCase;


}
