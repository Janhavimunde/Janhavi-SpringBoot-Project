package com.example.janhavi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JanhaviApplication {

	public static void main(String[] args) {
		SpringApplication.run(JanhaviApplication.class, args);
	}

}
