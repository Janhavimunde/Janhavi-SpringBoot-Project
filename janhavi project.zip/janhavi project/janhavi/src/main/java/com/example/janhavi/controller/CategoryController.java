package com.example.janhavi.controller;
import com.example.janhavi.model.Category;
import com.example.janhavi.repo.CategoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")

public class CategoryController {

    @Autowired
    CategoryRepo categoryrepo;

    @GetMapping("/getAll")
    public ResponseEntity<List<Category>> getAllCategories() {
        try {
            List<Category> categoryList = new ArrayList<>();
            categoryrepo.findAll().forEach(categoryList::add);

            if (categoryList.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(categoryList, HttpStatus.OK);
        } catch(Exception ex) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getCategoryById/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long id) {
        Optional<Category> categoryObj = categoryrepo.findById(id);
        if (categoryObj.isPresent()) {
            return new ResponseEntity<>(categoryObj.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/addCategory")
    public ResponseEntity<Category> addDemand(@RequestBody Category s) {
        try {
            Category s1 = categoryrepo.save(s);
            return new ResponseEntity<>(s1, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/updateCategory/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable long id, @RequestBody Category s) {
        try {
            Optional<Category> categoryData = categoryrepo.findById(id);
            if (categoryData.isPresent()) {
                Category updatedCategoryData = categoryData.get();
                updatedCategoryData.setWeight(s.getWeight());
                updatedCategoryData.setUseCase(s.getUseCase());

                Category categoryObj = categoryrepo.save(updatedCategoryData);
                return new ResponseEntity<>(categoryObj, HttpStatus.CREATED);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deleteCategoryById/{id}")
    public ResponseEntity<HttpStatus> deleteCategory(@PathVariable Long id) {
        try {
            categoryrepo.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
