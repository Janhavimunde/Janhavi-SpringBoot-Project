package com.example.janhavi.controller;


import com.example.janhavi.model.Product;
import com.example.janhavi.repo.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductController {

    @Autowired
    ProductRepo productrepo;

    @GetMapping("/getAll")
    public ResponseEntity<List<Product>> getAllProducts() {
        try {
            List<Product> productList = new ArrayList<>();
            productrepo.findAll().forEach(productList::add);

            if (productList.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(productList, HttpStatus.OK);
        } catch(Exception ex) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getProductById/{id}")
    public ResponseEntity<Product> getDemandById(@PathVariable Long id) {
        Optional<Product> productObj = productrepo.findById(id);
        if (productObj.isPresent()) {
            return new ResponseEntity<>(productObj.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/addProduct")
    public ResponseEntity<Product> addProduct(@RequestBody Product s) {
        try {
            Product s1 = productrepo.save(s);
            return new ResponseEntity<>(s1, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/updateProduct/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable long id, @RequestBody Product s) {
        try {
            Optional<Product> productData = productrepo.findById(id);
            if (productData.isPresent()) {
                Product updatedProductData = productData.get();
                updatedProductData.setProductName(s.getProductName());
                updatedProductData.setUseCase(s.getUseCase());

                Product productObj = productrepo.save(updatedProductData);
                return new ResponseEntity<>(productObj, HttpStatus.CREATED);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deleteProductById/{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable Long id) {
        try {
            productrepo.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}


