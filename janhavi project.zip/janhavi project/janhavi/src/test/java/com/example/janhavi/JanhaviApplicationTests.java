package com.example.janhavi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JanhaviApplicationTests {

	@Test
	void contextLoads() {
	}

}
